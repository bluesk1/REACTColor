import csv
import time
import pandas as pd
import plotly.graph_objects as go
from PIL import Image
from cv2 import *
import PySimpleGUIWeb as sg
import shutil
import smtplib as smptlib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from functions import *

def main():
    cap = VideoCapture(int(sys.argv[3]))

    l, n, pl, react_id, email_address = graphicalInterface()

    l = int(l)
    n = int(n)
    r = int(l / n)
    os.chdir(str(pl))
    os.mkdir(str(react_id))
    os.chdir(str(react_id))

    with open('final.csv', 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['time', 'r', 'g', 'b'])
        for i in range(r):
            takePicture(i, pl, react_id, n, cap, writer)
    cap.release()

    postProcess(pl, react_id, email_address, l, n)

if __name__ == "__main__":
    main()




